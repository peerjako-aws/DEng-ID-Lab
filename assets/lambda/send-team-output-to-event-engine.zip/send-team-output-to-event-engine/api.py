import urllib.parse

import boto3
import requests

class EEAPIClient:

  def __init__(self, api_base, api_token, game_id, module_id):
    self.api_base = api_base
    self.api_token = api_token
    self.game_id = game_id
    self.module_id = module_id
    # clients
    self.sts_client = boto3.client('sts')


  def get_game(self):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}")
    r = requests.get(url, headers=self._get_headers())
    return r.json()

  def get_all_teams(self):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}/teams")
    r = requests.get(url, headers=self._get_headers())
    return r.json()['teams']

  def get_one_team(self, team_id):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}/teams/{team_id}")
    r = requests.get(url, headers=self._get_headers())
    return r.json()

  def assume_team_ops_role(self, team_id, duration=30*60):
    team = self.get_one_team(team_id)
    assume_response = self.sts_client.assume_role(
      RoleArn=team['account']['ops-role-arn'],
      RoleSessionName='GameDayClientSDK',
      DurationSeconds=duration,
    )
    xa_session = boto3.Session(
      aws_access_key_id=assume_response['Credentials']['AccessKeyId'],
      aws_secret_access_key=assume_response['Credentials']['SecretAccessKey'],
      aws_session_token=assume_response['Credentials']['SessionToken']
    )
    return xa_session

  def set_checkpoint(self, team_id, checkpoint):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}/teams/{team_id}/modules/{self.module_id}/checkpoints")
    requests.post(url, json={
      "checkpoint": checkpoint
    }, headers=self._get_headers())
    return

  def points(self, team_id, points, reason=None):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}/teams/{team_id}/score")
    requests.post(url, json={
      "type": "points",
      "value": points,
      "reason": reason
    }, headers=self._get_headers())
    return

  def points_ppm(self, team_id, weight, reason):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}/teams/{team_id}/score")
    requests.post(url, json={
      "type": "ppm",
      "value": weight,
      "reason": reason
    }, headers=self._get_headers())
    return

  def get_input(self, team_id, key):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}/teams/{team_id}/modules/{self.module_id}/inputs/{key}")
    r = requests.get(url, headers=self._get_headers())
    return r.json()

  def post_input(self, team_id, key, label, description=None):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}/teams/{team_id}/modules/{self.module_id}/inputs")
    requests.post(url, json={
      "key": key,
      "label": label,
      "description": description
    }, headers=self._get_headers())
    return

  def post_output(self, team_id, key, label, value, description=None):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}/teams/{team_id}/modules/{self.module_id}/outputs")
    requests.post(url, json={
      "key": key,
      "label": label,
      "value": value,
      "description": description
    }, headers=self._get_headers())
    return

  def get_config(self, team_id, key):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}/teams/{team_id}/modules/{self.module_id}/config/{key}")
    r = requests.get(url, headers=self._get_headers())
    return r.json()

  def set_config(self, team_id, key, value):
    url = urllib.parse.urljoin(self.api_base, f"games/{self.game_id}/teams/{team_id}/modules/{self.module_id}/config")
    requests.post(url, json={
      "key": key,
      "value": value,
    }, headers=self._get_headers())
    return

  def _get_headers(self):
    return { 
      'Authorization': f'Bearer {self.api_token}', 
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    }
