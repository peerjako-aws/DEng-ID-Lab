import json
import os
import api                                          # Helper class for interacting with Event Engine API
import traceback
import outputmappings as output_mappings            # Used to map our CloudFormation output keys to friendly labels in the team's EE dashboard
from botocore.exceptions import ClientError

# -------------------------------- PURPOSE -------------------------------------
# This function runs in the master account and is invoked by Lambdas (or other
# resources) witin the master account or within a team account. The invocation 
# includes the target team ID and an output key/value pair to send to the EE
# dashboard of the specified team.
#
# If you wanted to send the same output to all teams, you should invoke
# this function in a loop for all team IDs (obtained from the EE API). This
# function could be improved by adding an optional parameter that specifies a
# given output should be sent to all teams and, if that param is present/true, 
# this function could get the team IDs by making an API call to the EE API. 
# ------------------------------------------------------------------------------

# These env vars flow from the Lambda's environment property in the master
# CloudFormation template for this module. The params in CloudFormation are
# dynamically populated by Event Engine when the event is started. 
api_base = os.environ['API_BASE']
api_token = os.environ['API_TOKEN']
event_region = os.environ['EVENT_REGION']
event_id = os.environ['EVENT_ID']
module_id = os.environ['MODULE_ID']

def handler(event, context):
    try:
        print("Event:" + json.dumps(event, indent=2))

        team_id = event['team_id']
        output_key = event['output_key']
        output_value = event['output_value']
        output_label = output_key

        # if we've defined a friendly name for the given output_key, use that instead:
        if (output_key in output_mappings.labels):
            output_label = output_mappings.labels[output_key]

        print("Posting output to Event Engine:")
        print("  - Key: " + output_key)
        print("  - Label: " + output_label)
        print("  - Value: " + output_value)

        ee_obj = api.EEAPIClient(api_base, api_token, event_id, module_id)
        ee_obj.post_output(  
            team_id, 
            output_key,   
            output_label,  
            output_value
        )
        return {
            "status": 200,
            "message": "Done!"
        }
    except Exception as e:
        msg = "Unexpected error: {}".format(e)
        print(msg)
        traceback.print_exc()
        return {
            "status": 500,
            "message": msg
        }