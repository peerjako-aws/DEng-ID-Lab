# -------------------------------- PURPOSE -------------------------------------
# Provide an optional mapping of CloudFormation output key's to the label we 
# want to display on the team's Event Engine dashboard. If a mapping is not
# present we will simply use the Output key as its displayed label. 

labels = {
	"GlueLabRole": "Glue Lab Role",
	"DMSLabRoleS3": "DMSLabRoleS3 ARN",
	"BucketName": "S3 Bucket name"
}